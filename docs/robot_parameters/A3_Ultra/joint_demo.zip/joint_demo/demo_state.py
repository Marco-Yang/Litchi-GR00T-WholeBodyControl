import rclpy
from rclpy.node import Node
from joint_msgs.msg import JointState

class JointStateSubscriber(Node):
    def __init__(self):
        super().__init__('joint_state_subscriber')
        self.subscription = self.create_subscription(
            JointState,
            '/body_drive/leg_joint_state',
            self.listener_callback,
            10
        )
        self.get_logger().info('订阅者已启动，正在监听话题: /body_drive/leg_joint_state')

    def listener_callback(self, msg):
        # 1. 提取时间戳与帧ID
        sec = msg.header.stamp.sec
        nsec = f"{msg.header.stamp.nanosec:09d}"
        frame = msg.header.frame_id
        self.get_logger().info(f"📥 收到数据 | 时间: {sec}.{nsec} | 坐标系: {frame}")

        # 2. 打印表头
        self.get_logger().info(f"{'关节名称':<25} | {'位置(pos)':^12} | {'速度(vel)':^12} | {'扭矩(eff)':^12}")
        self.get_logger().info("-" * 75)

        # 3. 逐行格式化输出关节状态
        for j in msg.joints:
            self.get_logger().info(
                f"{j.name:<25} | {j.position:+12.6f} | {j.velocity:+12.6f} | {j.effort:+12.6f}"
            )
        self.get_logger().info("=" * 75)

def main(args=None):
    try:
        rclpy.init(args=args)
        node = JointStateSubscriber()
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\n🛑 接收到 Ctrl+C，正在退出节点...")
    except Exception as e:
        print(f"❌ 节点运行出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if 'node' in locals():
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f"!!! 脚本报错退出: {e}")
        import traceback
        traceback.print_exc()

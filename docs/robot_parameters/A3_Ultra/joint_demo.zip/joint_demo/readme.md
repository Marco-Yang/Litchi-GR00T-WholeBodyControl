本demo针对/body_drive/leg_joint_command 话题与 /body_drive/leg_joint_state 话题

文件介绍：
joint_msgs_proto_x86_64 、joint_msgs_proto_aarch64 为预编译x86、arm环境下上述两个话题的自定义msg ros环境。
joint_msgs 内为相关话题数据格式
demo_command.py  接收/body_drive/leg_joint_command话题例程
demo_state.py 接收/body_drive/leg_joint_state 话题例程
使用：
第一步：修改机上通信形式：
	真机：mdu下对应机型的yaml  以下以t2.5为例：agibot/config/hal_ethercat/hal_ethercat_a3_t2d5_cfg.yaml  添加/body_drive/leg_joint_command 和 /body_drive/leg_joint_state的ros2 通信形式
	仿真：按照二开文档要求将aimsim中的/body_drive/leg_joint_state 话题改为ros2
第二步：加载ros2预编译环境
	终端执行：source joint_msgs_proto_x86_64/share/joint_msgs/local_setup.bash  (x86下执行)
		  source joint_msgs_proto_aarch64/share/joint_msgs/local_setup.bash  （arm架构下执行）
	注意：如遇到不兼容问题 请自行编译joint_msgs文件夹，在文件夹内执行 ./build.sh即可
第三步：关闭mc模块
	真机：
		
		关闭mc模块：curl -i   -H 'content-type:application/json'   -X POST 'http://10.42.10.10:50080/json/stop_app'   -d '{"app_name": "mc"}'
		开启mc模块：curl -i   -H 'content-type:application/json'   -X POST 'http://10.42.10.10:50080/json/start_app'   -d '{"app_name": "mc"}'
	仿真：不启动mc工具即可
	

第四步：
	收state状态：python3 demo_state.py 
	发command命令：python3 demo_command.py （真机需先执行source /agibot/software/v0/entry/env/env.sh加载ros环境）




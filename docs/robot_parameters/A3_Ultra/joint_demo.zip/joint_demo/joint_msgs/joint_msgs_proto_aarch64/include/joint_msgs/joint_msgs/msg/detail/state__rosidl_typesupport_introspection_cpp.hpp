// generated from rosidl_typesupport_introspection_cpp/resource/idl__rosidl_typesupport_introspection_cpp.h.em
// with input from joint_msgs:msg/State.idl
// generated code does not contain a copyright notice

#ifndef JOINT_MSGS__MSG__DETAIL__STATE__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
#define JOINT_MSGS__MSG__DETAIL__STATE__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

// TODO(dirk-thomas) these visibility macros should be message package specific
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, joint_msgs, msg, State)();

#ifdef __cplusplus
}
#endif

#endif  // JOINT_MSGS__MSG__DETAIL__STATE__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_

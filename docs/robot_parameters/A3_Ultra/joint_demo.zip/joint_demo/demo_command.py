import rclpy
from rclpy.node import Node

from joint_msgs.msg import JointCommand
from joint_msgs.msg import Command

from rclpy.qos import QoSProfile, ReliabilityPolicy


class RightLegDemoPublisher(Node):

    def __init__(self):
        super().__init__('right_leg_demo_publisher')

        # QoS 设置
        qos = QoSProfile(
            depth=10,
            reliability=ReliabilityPolicy.BEST_EFFORT
        )

        # Publisher
        self.publisher_ = self.create_publisher(
            JointCommand,
            '/body_drive/leg_joint_command',
            qos
        )

        # 50Hz 定时器
        self.timer = self.create_timer(
            0.02,
            self.timer_callback
        )

        self.get_logger().info('右腿弯曲 Demo 已启动')

    def make_joint(
        self,
        name,
        position,
        velocity=0.0,
        effort=0.0,
        stiffness=40.0,
        damping=4.0
    ):
        """
        创建单个关节命令
        """

        joint = Command()

        joint.name = name
        joint.sequence = 0

        joint.position = position
        joint.velocity = velocity
        joint.effort = effort

        joint.stiffness = stiffness
        joint.damping = damping

        return joint

    def timer_callback(self):

        msg = JointCommand()

        # Header
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "base"

        joints = []

        # ==================================================
        # 左腿（保持站立）
        # ==================================================

        joints.append(
            self.make_joint(
                'left_hip_pitch_joint',
                -0.1
            )
        )

        joints.append(
            self.make_joint(
                'left_hip_roll_joint',
                0.0
            )
        )

        joints.append(
            self.make_joint(
                'left_hip_yaw_joint',
                0.0
            )
        )

        joints.append(
            self.make_joint(
                'left_knee_joint',
                0.2
            )
        )

        joints.append(
            self.make_joint(
                'left_ankle_pitch_joint',
                -0.1
            )
        )

        joints.append(
            self.make_joint(
                'left_ankle_roll_joint',
                0.0
            )
        )

        # ==================================================
        # 右腿（弯曲）
        # ==================================================

        joints.append(
            self.make_joint(
                'right_hip_pitch_joint',
                -0.3
            )
        )

        joints.append(
            self.make_joint(
                'right_hip_roll_joint',
                0.0
            )
        )

        joints.append(
            self.make_joint(
                'right_hip_yaw_joint',
                0.0
            )
        )

        joints.append(
            self.make_joint(
                'right_knee_joint',
                0.6
            )
        )

        joints.append(
            self.make_joint(
                'right_ankle_pitch_joint',
                -0.3
            )
        )

        joints.append(
            self.make_joint(
                'right_ankle_roll_joint',
                0.0
            )
        )

        # 填入消息
        msg.joints = joints

        # 发布
        self.publisher_.publish(msg)

        self.get_logger().info('已发送右腿弯曲控制命令')


def main(args=None):

    rclpy.init(args=args)

    node = RightLegDemoPublisher()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        print("\n🛑 接收到 Ctrl+C，正在退出...")

    finally:
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()